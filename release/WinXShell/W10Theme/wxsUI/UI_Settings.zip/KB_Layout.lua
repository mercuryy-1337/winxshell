local localeid = nil
function onload()
  localeid = Reg:Read([[HKEY_USERS\.DEFAULT\Control Panel\International]], 'Locale')
  if localeid == nil then return end
  App:Print('LCID' .. localeid)
  localeid = string.sub(localeid, -4, -1)
  --:: Update registry keyboard layouts in HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinPE\KeyboardLayouts
  App:Run('Wpeutil.exe', 'ListKeyboardLayouts 0x' .. localeid)
end

function onclick(ctrl)
  App:Run('Wpeutil.exe', string.format('SetKeyboardLayout 0x%s:%s', localeid, ctrl))
  sui:hide()
  App:Sleep(3000) -- ?
  sui:close()
end
