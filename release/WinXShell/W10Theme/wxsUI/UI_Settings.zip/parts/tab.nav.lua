

function NavTab_OnClick(self, tab, ctrl)
    App:Debug('NavTab_OnClick - ' .. tab  .. ' ' .. tostring(ctrl))
  
    if UI.Inited == 1 then
      if display_applybtn.visible == 1 then
        display_applybtn_click()
      end
    end
  
    self:DefOnClick(tab)
  end
  
  function NavTab_Init()
    if os.winname == 'Win11' then
      sui:find('Nav_QuickAccess').text = "<b>#{@shell32.dll,51384}</b>"
    end
    sui:find('ctrlpanel_button').text = sui:find('ctrlpanel_button').text
    local nav = UITab.New('$Nav')
    nav:BindLayout('TabLayoutMain')
    nav:SetList({
      'SystemInfo',
      'Display',
      'Background',
      'Colors',
      'FolderOptions',
      'Taskbar'
    })
    nav.OnClick = NavTab_OnClick
    return nav
  end

  
UI.OnClick['ctrlpanel_button'] = function()
  wxs_open('controlpanel')
end

UI.OnClick['compmgmt_button'] = function()
  App:Run('compmgmt.msc')
end

