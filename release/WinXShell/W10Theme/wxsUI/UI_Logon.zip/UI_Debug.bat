cd /d "%~dp0..\.."
rem set logon_script=D:\Dev\Shell\ReleaseWinXShell\WinXShell_x64\pecmd.lua
x64\Debug\WinXShell.exe -console -ui  -user Administrator -jcfg wxsUI\UI_Logon\UI_LogonPE.jcfg
pause
x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_Logon\UI_LogonPE.jcfg -user SYSTEM
pause
x64\Debug\WinXShell.exe  -console -ui -jcfg wxsUI\UI_Logon\main.jcfg -bk bk.jpg
pause
x64\Debug\WinXShell.exe -ui -jcfg wxsUI\UI_Logon\main.jcfg
pause
x64\Debug\WinXShell.exe -ui -jcfg wxsUI\UI_Logon\main.jcfg -blur 8 -bk bk2.jpg
goto :EOF

x64\Debug\WinXShell.exe -ui -jcfg wxsUI\UI_Logon\main.jcfg -blur 12 -bk bk3.jpg
