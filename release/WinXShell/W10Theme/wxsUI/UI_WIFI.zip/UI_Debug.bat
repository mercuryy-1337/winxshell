cd /d "%~dp0..\.."

start x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_WIFI\main.jcfg -theme light
pause
start x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_WIFI\main.jcfg -hidewindow
pause
start x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_WIFI\main.jcfg -theme dark
pause
start x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_WIFI\main.jcfg -theme light