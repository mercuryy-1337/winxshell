@echo off
cd /d "%~dp0..\.."

call :GetWinXShell
call :GetFolderName "%~p0"

start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\main.jcfg
pause
start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\main.jcfg -brightness=false
pause
start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\main.jcfg -theme light
pause
start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\Calendar.jcfg
pause
start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\Calendar.jcfg -theme dark
pause
start "" %WINXSHELL% -console -jcfg wxsUI\%p0%\Calendar.jcfg -theme light
goto :EOF

:GetWinXShell
if exist x64\Debug\WinXShell.exe set WINXSHELL=x64\Debug\WinXShell.exe&&goto :EOF
if exist WinXShell.exe set WINXSHELL=WinXShell.exe&&goto :EOF
if exist WinXShell_%PROCESSOR_ARCHITECTURE%.exe set WINXSHELL=WinXShell_x86.exe&&goto :EOF
set WINXSHELL=WinXShell_x64.exe
goto :EOF

:GetFolderName
if "x%~2"=="x1" set "p0=%~n1" && goto :EOF
set "p0=%~1"
set p0=%p0:~0,-1%
call :GetFolderName  "%p0%" 1
goto :EOF
