cd /d "%~dp0..\.."
start x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_Resolution\main.jcfg