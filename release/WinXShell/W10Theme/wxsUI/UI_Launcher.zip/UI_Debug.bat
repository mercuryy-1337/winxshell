cd /d "%~dp0..\.."
x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_Launcher\main.jcfg
pause
x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_Launcher\full.jcfg -custom
pause
x64\Debug\WinXShell.exe -console -ui -jcfg wxsUI\UI_Launcher\startmenu.jcfg
pause